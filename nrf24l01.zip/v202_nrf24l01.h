void *V202_Cmds(enum ProtoCmds cmd);
