void *HonTai_Cmds(enum ProtoCmds cmd);
