void *ESKY_Cmds(enum ProtoCmds cmd);
