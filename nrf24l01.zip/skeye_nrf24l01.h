void *Skeye_Cmds(enum ProtoCmds cmd);
