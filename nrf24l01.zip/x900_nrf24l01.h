void *X900_Cmds(enum ProtoCmds cmd);
