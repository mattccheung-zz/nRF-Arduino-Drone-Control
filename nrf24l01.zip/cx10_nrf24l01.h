void *CX10_Cmds(enum ProtoCmds cmd);
