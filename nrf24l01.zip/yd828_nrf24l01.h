void *YD828_Cmds(enum ProtoCmds cmd);
