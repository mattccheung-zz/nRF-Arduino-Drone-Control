void *Devo_Cmds(enum ProtoCmds cmd);
