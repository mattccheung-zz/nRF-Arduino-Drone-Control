void *SYMAX_Cmds(enum ProtoCmds cmd);
