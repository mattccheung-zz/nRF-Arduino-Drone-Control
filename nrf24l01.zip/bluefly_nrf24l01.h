void *BlueFly_Cmds(enum ProtoCmds cmd);
