void *GP993_Cmds(enum ProtoCmds cmd);
