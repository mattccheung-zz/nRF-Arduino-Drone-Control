void *ESKY150_Cmds(enum ProtoCmds cmd);
